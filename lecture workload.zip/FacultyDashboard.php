<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/AdminDashboard.css">
</head>

<body>
    <header>
        <img src="Images/AIUB.png" alt="Header Image">
    </header>
    <nav>
        <ul>
            <h3>
                <li><a href="FacultyHome.php">Home</a></li>
                <li><a href="tsf_Faculty.php">TSF</a></li>
                <!-- <li><a href="facultyPriorityTime.php">Add Priority Time</a></li> -->
                <!-- <li><a href="AddPriorityCourse.php">Add Priority Courses</a></li> -->
                <li><a href="changePasswordF.php">Change Password</a></li>
                <!-- <li><a href="login.php">Logout</a></li> -->
            </h3>
        </ul>
    </nav>
</body>

</html>










<!-- 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.min.css">
    <script src="bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
    <script src="bootstrap-5.3.2-dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <a href="FacultyHome.php"><img src="Images/banner.png" id="aiubBanner" alt="Header Image"></a>
    <div class="main">
    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
            <button id="navButton" class="w3-bar-item w3-button w3-large" onclick="w3_close()">Close &times;</button>
            <a href="FacultyHome.php" class="w3-bar-item w3-button">Home</a>
            <a href="tsf_Faculty.php" class="w3-bar-item w3-button">TSF</a>
            <a href="changePasswordF.php" class="w3-bar-item w3-button">Change Password</a>
            
        </div>
        <div class="w3-teal">
            <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;</button>
        </div>
        <script>
            function w3_open() {
                document.getElementById("mySidebar").style.width = "25%";
                document.getElementById("mySidebar").style.display = "block";
                document.getElementById("openNav").style.display = 'none';
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
                document.getElementById("openNav").style.display = "inline-block";
            }
        </script>
    </div>
</body>

</html> -->

